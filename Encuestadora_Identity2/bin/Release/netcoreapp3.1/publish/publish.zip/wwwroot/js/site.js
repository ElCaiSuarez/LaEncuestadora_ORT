﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function cambioCustomTag() {

    //var mensajeCustomTag = document.getElementById("mensajeCustomTag");
    //mensajeCustomTag.value = "Crear una cuenta de Cliente.";
    var customTag = document.getElementById("CustomTag");
    alert(customTag);
    //customTag.value = "Cliente";
    //alert("Ya puede crear su cuenta de Cliente")
}
function canjear() {
    alert("Puntos Canjeados...(Fuera del alcance del proyecto) Implementar un carrito de compras con GiftCards, para canjear por los puntos del USUARIO")
}
function cobrar() {
    alert("Membresia Cobrada...(Fuera del alcance del proyecto) Implementar un sistema de cobro online, para la membresia del CLIENTE")
}